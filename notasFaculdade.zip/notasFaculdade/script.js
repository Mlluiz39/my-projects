const calcular = document.getElementById("calcular");
const calcularN2 = document.getElementById("calcularN2");
const soma = document.getElementById("soma");


function calculaN1(a1, a2, a3, a4) {
  var a1 = document.getElementById("a1").value;
  var a2 = document.getElementById("a2").value;
  var a3 = document.getElementById("a3").value;
  var a4 = document.getElementById("a4").value;
  
  resultado = ((parseInt(a1) + parseInt(a2) + parseInt(a3) + parseInt(a4)) / 4) * 0.4;
 
  document.getElementById(
    "resultado"
  ).innerHTML = `Sua média é => ${resultado.toFixed(1)}`;
  
};

function calculaN2(notaN2) {
  var notaN2 = document.getElementById("n2").value;
  var resultado2 = parseInt(notaN2) * 0.6;

  document.getElementById(
    "resultado2"
  ).innerHTML = `Sua média é => ${resultado2.toFixed(1)}`;
 
};

function media() {
  var resultado3 = (parseInt(resultado) + parseInt(resultado2));
  
  document.getElementById(
    "resultado3"
  ).innerHTML = `Sua média final é => ${resultado3}`;
  
};











// console.log(calculaN1().toFixed(2));
// console.log(calculaN2().toFixed(2));
// console.log(`Total das duas notas: ${soma}`);
// console.log(`Com essa nota: ${soma}
